"""Read one-dimensional barcodes and QR codes from Python 2 and 3."""

__version__ = '0.1.9'
