#### READ ME ###
-Install ตามปกติ
** ต้องใช้งานด้วยสิทธ์ ADMIN เสมอ
** QR-CODE จะถูกบันทึกไว้ที่โฟเดอร์  C:\Program Files\AI & QR Code Scanner\data\save 